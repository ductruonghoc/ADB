﻿--1) Stored Procedures
--a) Thêm mới chi nhánh
use QLNHAHANG;
DROP PROCEDURE IF EXISTS sp_ThemChiNhanh;
go
CREATE PROCEDURE sp_ThemChiNhanh
    @MaCN NVARCHAR(20),
    @TenChiNhanh NVARCHAR(100),
    @ThoiGianMo TIME,
    @ThoiGianDong TIME,
    @SoDienThoai CHAR(15),
    @DiaChi NVARCHAR(255),
    @MaKV INT,
    @BaiDoXeHoi BIT,
    @BaiDoXeMay BIT
AS
BEGIN
    INSERT INTO CHINHANH (MaCN, TenChiNhanh, ThoiGianMo, ThoiGianDong, SoDienThoai, DiaChi, MaKV, BaiDoXeHoi, BaiDoXeMay)
    VALUES (@MaCN, @TenChiNhanh, @ThoiGianMo, @ThoiGianDong, @SoDienThoai, @DiaChi, @MaKV, @BaiDoXeHoi, @BaiDoXeMay);
END;
go
EXEC sp_ThemChiNhanh
    @MaCN = '16',
    @TenChiNhanh = N'Chi Nhánh 1',
    @ThoiGianMo = '08:00:00',
    @ThoiGianDong = '22:00:00',
    @SoDienThoai = '0912345678',
    @DiaChi = N'123 Đường ABC, TP. HCM',
    @MaKV = 855004,
    @BaiDoXeHoi = 1,
    @BaiDoXeMay = 1;
go
--b) Lấy danh sách nhân viên của chi nhánh
CREATE PROCEDURE sp_LayDanhSachNhanVien
    @MaCN tinyint
AS
BEGIN
    SELECT NV.MaNV, NV.HoTen, NV.NgaySinh, NV.GioiTinh, NV.DiaChi, BP.TenBoPhan
    FROM NHANVIEN NV
    INNER JOIN LICHSULAMVIEC LS on NV.MaNV = LS.MaNV
	INNER JOIN BOPHAN BP on LS.MaBoPhan = BP.MaBoPhan
    WHERE LS.MaCN = @MaCN
	and LS.ThoiGianKetThuc IS NULL;
END;

EXEC sp_LayDanhSachNhanVien 
    @MaCN = 5;
go
--c) Thêm mới thẻ thành viên
CREATE PROCEDURE sp_ThemTheThanhVien
    @LoaiThe INT,
    @DiemTichLuy INT,
    @NgayTao DATE,
    @NgayDatHangThe DATE,
    @MaKH INT,
    @NhanVienLapThe INT
AS
BEGIN
    -- Bắt đầu transaction
    BEGIN TRANSACTION;

    BEGIN TRY
        -- Kiểm tra xem mã thẻ đã tồn tại chưa
        IF EXISTS (
            SELECT 1 FROM THETHANHVIEN WHERE LoaiThe = @LoaiThe and MaKH = @MaKH
        )
        BEGIN
            THROW 50001, 'Mã thẻ đã tồn tại!', 1;
        END

        -- Kiểm tra sự tồn tại của khách hàng
        IF NOT EXISTS (
            SELECT 1 FROM KHACHHANG WHERE MaKH = @MaKH
        )
        BEGIN
            THROW 50002, 'Khách hàng không tồn tại!', 1;
        END

        -- Kiểm tra sự tồn tại của nhân viên
        IF NOT EXISTS (
            SELECT 1 FROM NHANVIEN WHERE MaNV = @NhanVienLapThe
        )
        BEGIN
            THROW 50003, 'Nhân viên không tồn tại!', 1;
        END

        -- Thêm thẻ mới vào bảng THETHANHVIEN
        INSERT INTO THETHANHVIEN (
            LoaiThe, DiemTichLuy, NgayTao, NgayDatHangThe, MaKH, NhanVienLapThe
        ) VALUES (
            @LoaiThe, @DiemTichLuy, @NgayTao, @NgayDatHangThe, @MaKH, @NhanVienLapThe
        );

        -- Hoàn thành transaction
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        -- Rollback nếu có lỗi
        ROLLBACK TRANSACTION;

        -- Trả lỗi ra màn hình
        DECLARE @ErrorMessage NVARCHAR(4000);
        DECLARE @ErrorSeverity INT;
        DECLARE @ErrorState INT;

        SELECT 
            @ErrorMessage = ERROR_MESSAGE(),
            @ErrorSeverity = ERROR_SEVERITY(),
            @ErrorState = ERROR_STATE();

        RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
    END CATCH
END;
go
EXEC sp_ThemTheThanhVien
    @LoaiThe = 4,
    @DiemTichLuy = 150,
    @NgayTao = '2024-11-29',
    @NgayDatHangThe = '2024-12-10',
    @MaKH = 710,
    @NhanVienLapThe = 171;
go
--d) Them Mon an vao ban an
CREATE PROCEDURE str_ThemMonAnVaoBan 
 @MaBanAn tinyint, 
 @MaMon int, 
    @SoLuong int 
AS 
BEGIN  
 BEGIN TRANSACTION; 
 
  INSERT INTO BANAN_MONAN  
  (MaBanAn, MaMon, SoLuong) 
  VALUES  
  (@MaBanAn, @MaMon, @SoLuong); 
 
  COMMIT TRANSACTION; 
 
  IF @@ERROR <> 0 
  BEGIN  
   ROLLBACK TRANSACTION; 
  END; 
END;
--e) Lap Hoa don
GO
CREATE PROCEDURE str_LapHoaDon( 
 @MaBanAn INT, 
 @NgayTao DATE, 
 @MaThe INT, 
 @MaNV INT, 
 @SoTien FLOAT OUTPUT) 
AS 
BEGIN 
 DECLARE @TongTien FLOAT = 0; 
 
    -- Tính tổng tiền các món ăn trên bàn 
    SELECT @TongTien = SUM(ma.Gia * 
bm.SoLuong) 
    FROM BANAN_MONAN bm 
    JOIN MONAN ma ON bm.MaMon = ma.ID 
    WHERE bm.MaBanAn = @MaBanAn; 
 
    -- Nếu không có món ăn nào được gọi, thoát thủ tục 
    IF @TongTien IS NULL OR @TongTien = 0 
    BEGIN 
        PRINT 'Không có món ăn nào được gọi trên 
bàn này.'; 
        RETURN; 
    END; 
 
    -- Thêm hóa đơn mới vào bảng HOADON 
 
    INSERT INTO HOADON (NgayTao, SoTien, 
MaThe, MaBanAn, MaNV) 
    VALUES (@NgayTao, @TongTien, @MaThe, 
@MaBanAn, @MaNV); 
 
    -- Trả tổng tiền ra biến OUTPUT 
    SET @SoTien = @TongTien; 
 
    PRINT 'Hóa đơn đã được tạo thành công với tổng 
tiền: ' + CAST(@TongTien AS NVARCHAR(50)); 
END;
GO
exec str_LapHoaDon 500, '12-22-2024', 1, 1, 0;
GO
--f) Lay thong tin mon an dang dung trong thuc don tung chi nhanh
CREATE PROCEDURE str_LayThongTinMonAn 
    @MaCN tinyint 
AS 
BEGIN 
    SELECT   
        ma.TenMonAn,  
        ma.NguyenLieu,  
        ma.URL,  
        m.Gia,  
        m.NgayTao,  
        m.DangDung,  
        td.TenThucDon,  
        mt.TenMuc 
    FROM THUCDON td 
 INNER JOIN MUCTHUCDON mt ON 
mt.MaTD = td.MaTD 
    INNER JOIN MONAN m ON m.MaMuc = 
mt.MaMuc 
    INNER JOIN KHOMONAN ma ON 
m.MaMonAn = ma.MaMonAn 
    WHERE td.MaCN = @MaCN and m.DangDung = 1
    ORDER BY  
        td.TenThucDon, mt.TenMuc, 
ma.TenMonAn; 
END;

GO
exec str_LayThongTinMonAn 5;
GO
--Đăng nhập
create procedure str_Login 
@role int,
@id int,
@password char(50)
as
begin
	--Staff
	--use MaNV as ID, NgaySinh as Password
	if @role = 1
	begin
		declare @date date = try_cast(@password as date);
		--cast fail
		if @date is NULL
		begin
			return;
		end;
		--find the valid id, password pair
		 select MaNV as ID
		 from NHANVIEN
		 where 
		 MaNV = @id and 
		 NgaySinh = @date;
		 return;
	end;
	--Customer
	if @role = 0
	begin
		
		 select MaKH as ID
		 from KHACHHANG
		 where 
		 MaKH = @id and 
		 SoDienThoai = @password;
	end;
end;
GO
exec str_Login
0,
105,
'0800 673 7735';
GO
create procedure str_Staff
@staffID int
as
begin
	select top 1 nv.HoTen as Name, 
	ls.MaBoPhan as DepartmentID,
	ls.MaCN as BranchID,
	bp.TenBoPhan as DepartmentName,
	cn.TenChiNhanh as BranchName
	from LICHSULAMVIEC ls
	inner join NHANVIEN nv on ls.MaNV = nv.MaNV
	inner join BOPHAN bp on ls.MaBoPhan = bp.MaBoPhan
	inner join CHINHANH cn  on ls.MaCN = ls.MaCN
	where nv.MaNV = @staffID and
	(ls.ThoiGianKetThuc is NULL or
	ls.ThoiGianKetThuc > GETDATE())
	order by ls.ThoiGianBatDau desc;
end;

exec str_Staff 105;

GO
create procedure str_using_Tables
@BranchID int
as
begin
	select top (20)
	ba.MaBan as ID,
	bn.TrangThaiBan as Status,
	ba.TenBan as Name,
	bn.MaBanAn as ServedTableID
	from BAN ba
	inner join BAN_BANAN bn on ba.MaBan = bn.MaBan
	where ba.MaCN = @BranchID and
	bn.TrangThaiBan = 'DangDung';
end;

exec str_using_Tables 1;

GO
create procedure str_Tables
@BranchID int,
@threshold int
as
begin
	select top (@threshold)
	ba.MaBan as ID,
	ba.TenBan as Name,
	'Trong' as Status,
	null as ServedTableID
	from BAN ba
	left join BAN_BANAN bn on ba.MaBan = bn.MaBan
	where ba.MaCN = @BranchID and
	(
		bn.TrangThaiBan is null or
		bn.TrangThaiBan = 'Trong'
	);
end;


exec str_Tables 1, 20;
GO

GO
create procedure str_serveNewTable 
@tableID int
as
begin
	declare @ServedTableID int;
	insert into BANAN (ThoiGianDen)
	values (GETDATE());

	if @@ROWCOUNT = 0
	return;
	
	set @ServedTableID = SCOPE_IDENTITY();

	insert into BAN_BANAN
	values (@ServedTableID, @tableID, 'DangDung');

	select @ServedTableID as ServedTableID;
end

GO

--2) Functions
--a) Tính điểm tích lũy từ hóa đơn
CREATE FUNCTION fn_TinhDiemTichLuy (@SoTien FLOAT)
RETURNS INT
AS
BEGIN
    DECLARE @Diem INT;
    SET @Diem = FLOOR(@SoTien / 100000); -- 1 điểm cho mỗi 100,000 đồng
    RETURN @Diem;
END;
go
SELECT dbo.fn_TinhDiemTichLuy(450000) AS DiemTichLuy;
go
--b) Kiểm tra trạng thái bàn
CREATE FUNCTION fn_TrangThaiBan (@MaBan INT)
RETURNS NVARCHAR(50)
AS
BEGIN
    DECLARE @TrangThai NVARCHAR(50);
    SELECT @TrangThai = TrangThaiBan FROM BAN WHERE MaBan = @MaBan;
    RETURN @TrangThai;
END;
go
SELECT dbo.fn_TrangThaiBan(10) AS TrangThaiBan;
go
--c) Tính lương thực nhận của nhân viên
CREATE FUNCTION fn_TinhLuongThucNhan (@MaNV CHAR(10))
RETURNS FLOAT
AS
BEGIN
    DECLARE @LuongCoBan FLOAT, @Thuong FLOAT, @KhauTru FLOAT, @LuongThucNhan FLOAT;
    SELECT TOP 1 @LuongCoBan = LuongCoBan, @Thuong = Thuong, @KhauTru = KhauTru
    FROM LUONG
    WHERE MaNV = @MaNV
    ORDER BY NgayNhan DESC;

    SET @LuongThucNhan = @LuongCoBan * (1 + (@Thuong - @KhauTru)/100);
    RETURN @LuongThucNhan;
END;
go
SELECT dbo.fn_TinhLuongThucNhan(171) AS LuongThucNhan;
go
--3) Triggers
--a) Tự động cập nhật trạng thái bàn khi thanh toán hóa đơn
create TRIGGER trg_CapNhatTrangThaiBan
ON HOADON
AFTER INSERT
AS
BEGIN
    DECLARE @MaBanAn INT;

    SELECT @MaBanAn = MaBanAn FROM inserted;

	UPDATE BAN_BANAN
	SET TrangThaiBan = 'Trong'
	WHERE MaBanAn = @MaBanAn;
END;
--b) Tính điểm tích lũy sau khi tạo hóa đơn
CREATE TRIGGER trg_TinhDiemTichLuy
ON HOADON
AFTER INSERT
AS
BEGIN
    DECLARE @MaThe INT, @SoTien FLOAT, @DiemTichLuy INT;
    SELECT @MaThe = MaThe, @SoTien = SoTien FROM inserted;

    SET @DiemTichLuy = dbo.fn_TinhDiemTichLuy(@SoTien);

    UPDATE THETHANHVIEN
    SET DiemTichLuy = DiemTichLuy + @DiemTichLuy
    WHERE MaThe = @MaThe;
END;
go
--c) Tính điểm tích lũy sau khi xóa hóa đơn
CREATE TRIGGER tg_CapNhatDiemTichLuySauXoaHoaDon
ON HOADON
AFTER DELETE
AS
BEGIN
    DECLARE @Diem FLOAT, @MaThe INT;
    SELECT @Diem = SoTien * 0.01, @MaThe = MaThe
    FROM DELETED;
    -- Cập nhật lại điểm tích lũy của thành viên sau khi xóa hóa đơn
    UPDATE THETHANHVIEN
    SET DiemTichLuy = case
	when DiemTichLuy - @Diem > 0 then DiemTichLuy - @Diem
	else 0
	end
    WHERE THETHANHVIEN.MaThe = @MaThe;
END;

DELETE FROM HOADON WHERE MaHD = 0;
SELECT * FROM THETHANHVIEN WHERE MaKH = 494;
